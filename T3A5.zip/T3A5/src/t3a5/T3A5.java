package t3a5;

import java.util.Scanner;

public class T3A5 {
    private String numeroDeCuenta;
    private int pin;
    private float saldo;


    public T3A5 (){}

    public T3A5(String numeroDeCuenta, int pin, float saldo) {
        this.numeroDeCuenta = numeroDeCuenta;
        this.pin = pin;
        this.saldo = saldo;
    }
    @Override
    public String toString(){
        String mensaje = "numero de cuenta: " + numeroDeCuenta;
        return mensaje;
    }
    public void consultarSaldo(){
        saldo = 850.87f;
        System.out.println("Tienes un saldo de:  " + getSaldo());
        
    }
    public void estadoDeCuenta(){
        System.out.println("ESTADO DE CUENTA\n\n"
                + "Cuenta: " + getNumeroDeCuenta()
                + "\nSaldo " + getSaldo()
                + "\n\nUltimos movimientos" );
    }
    public void retirarEfectivo() {
        if (getSaldo() > 0){
            System.out.println("Cuanto ");
        }else {
            System.out.println("NO PUEDO AYUDARTE CON ESTA OPERACION"
                    + "\nFONDOS INCUFICIENTES");
        }
    }    
    
    public void seguros(){
        System.out.println("SEGUROS"
                + "\n1. Seguro para tu audto"
                + "\n2. Seguro de vida"
                + "\n3 Seguro medico"
                + "\n4. Seguro de vivienda");
    }
    
    public void creditos(){
        System.out.println("CREDITOS"
                + "\n1. Hipotecario"
                + "\n2. Crediauto"
                + "\n3. Familiar"
                + "\n4. Personal");
    }
    
    public void salir(){
       System.err.println("Gracias....");
    }
    public String getNumeroDeCuenta() {
        return numeroDeCuenta;
        
    }

    public void setNumeroDeCuenta(String numeroDeCuenta) {
        this.numeroDeCuenta = numeroDeCuenta;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    
    }
    

