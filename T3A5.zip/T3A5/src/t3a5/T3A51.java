package t3a5;

import java.util.Scanner;

public class T3A51 {
    
    public static void main(String[] args){
    menu();
    }
    public static void menu(){
        T3A5 t3a5 = new T3A5();
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("BIENVENIDO A BANCO FD "
                + " " 
                + "1. Consultar saldo\n"
                + "2. Consultar estado de cuenta\n"
                + "3. Retirar efectivo\n"
                + "4. Otras oprciones\n"
                + "5. Salir"
                + "\n\nElija una operacion");
        int operaciones = scanner.nextInt();
        
        switch(operaciones) {
            case 1:
                t3a5.consultarSaldo();
                break;
                
            case 2:
                t3a5.estadoDeCuenta();
                break;
            case 3:
                t3a5.retirarEfectivo();
                break;
            case 4:
                System.out.println("1. Seguros\n"
                        + "2. Creditos\n\n"
                        + "Elija uno;");
                int opcion = scanner.nextInt();
                
                switch(opcion) {
                    case 1:
                    t3a5.seguros();
                    break;
                    
                    case 2:
                    t3a5.creditos();
                    break;
                    
                    default:
                    System.err.println("ELIJA UNA OPERACION VALIDA");
                    break;
                        
                }
                break;     
                        
            case 5:
                t3a5.salir();
                break;
                
                
                }
                
                    
        }
}
 

